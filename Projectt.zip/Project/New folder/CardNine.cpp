
#include "CardNine.h"


CardNine::CardNine(const CellPosition& pos) : Card9_11(pos, 9)
{
	cardNumber = 9;
}
void CardNine::ReadCardParameters(Grid* pGrid)
{
	Card9_11::ReadCardParameters(pGrid);
}
void CardNine::Apply(Grid* pGrid, Player* pPlayer)
{
	Card9_11::Apply(pGrid, pPlayer);
	if (pPlayer != Owner)
	{
		pPlayer->SetWallet(pPlayer->GetWallet() - fees);
		Owner->SetWallet(Owner->GetWallet() + fees);
	}
}
CardNine::~CardNine()
{

}