#include "CardTen.h"
CardTen::CardTen(const CellPosition& pos) : Card9_11(pos, 10)
{
	cardNumber = 10;
}
void CardTen::ReadCardParameters(Grid* pGrid)
{
	Card9_11::ReadCardParameters(pGrid);
}
void CardTen::Apply(Grid* pGrid, Player* pPlayer)
{
	Card9_11::Apply(pGrid, pPlayer);
	if (pPlayer != Owner)
	{
		pPlayer->SetWallet(pPlayer->GetWallet() - fees);
		Owner->SetWallet(Owner->GetWallet() + fees);
	}
}
CardTen::~CardTen()
{

}
