#include "Card9_11.h"
bool Card9_11::firstCardInitialized{ false };
bool Card9_11::isOwned{ false };
Card9_11::Card9_11(const CellPosition& pos, int cardNumber) :Card(pos)
{
	cardPrice = 0;
	fees = 0;
	if (cardNumber >= 9 && cardNumber < 12)
		this->cardNumber = cardNumber;
	
}
void Card9_11::ReadCardParameters(Grid* pGrid)
{
	if (firstCardInitialized == false)
	{
		if (ReadCardCommon(pGrid))
		{
			firstCardInitialized = true;
		}
	}
}

void Card9_11::Apply(Grid* pGrid, Player* pPlayer)
{
	int ans = 0;

	Card::Apply(pGrid, pPlayer);
	
	if (isOwned == false)
	{
		ApplyCommon(pGrid, pPlayer);
	}
}
Card9_11::~Card9_11()
{

}

void Card9_11::ApplyCommon(Grid* pGrid, Player* pPlayer) {
	int ans = 0;
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	pOut->PrintMessage("To buy this station press (1): ");
	ans = pIn->GetInteger(pOut);
	pOut->ClearStatusBar();
	if (ans == 1)
	{
		pPlayer->SetWallet(pPlayer->GetWallet() - cardPrice);
		pGrid->PrintErrorMessage("Congratulations!! You are now the owner of the station: ");
		Owner = pPlayer;
		isOwned = true;
		pOut->ClearStatusBar();
	}
}

bool Card9_11::ReadCardCommon(Grid* pGrid) {
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	bool valueFlag = false;
	bool feesFlag = false;
	pOut->PrintMessage("New Card" + to_string(cardNumber) + ": Enter Card Price : ");
	int value = pIn->GetInteger(pOut);
	if (value > 0)
	{
		cardPrice = value;
		valueFlag = true;
	}
	pOut->ClearStatusBar();
	pOut->PrintMessage("Enter Station fees: ");
	int x = pIn->GetInteger(pOut);
	if (x > 0)
	{
		fees = x;
		feesFlag = true;

	}
	
	if (feesFlag && valueFlag) return true;

}