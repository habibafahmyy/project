#pragma once
#include "Action.h"
#include "Card.h"
#include "Grid.h"

class Copy :public Action
{
	CellPosition cellpos;
	
public:
	Copy(ApplicationManager*pApp);
	virtual void ReadActionParameters();
	
	
};

