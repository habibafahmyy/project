#pragma once
#include "Action.h"
class CutCard :public Action
{

};

