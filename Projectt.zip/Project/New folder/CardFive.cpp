#include "CardFive.h"
CardFive::CardFive(const CellPosition& pos) :Card(pos)
{
	cardNumber = 5;
}
void CardFive::ReadCardParameters(Grid* pGrid)
{
	
	
}

void CardFive::Apply(Grid* pGrid, Player* pPlayer)
{
	
	Card::Apply(pGrid, pPlayer);
   int n= (pPlayer->GetCell()->GetCellPosition().GetCellNum())-(pPlayer->getjustRolledDiceNum()-1);
   CellPosition C;
   C.GetCellPositionFromNum(n);
   pPlayer->MoveToCell(pGrid,C);

}
CardFive::~CardFive()
{

}
