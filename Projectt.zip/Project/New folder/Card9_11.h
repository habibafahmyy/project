#pragma once
#include "Card.h"
class Card9_11 :public Card
{
protected:
	int cardPrice;
	int fees;
	static bool firstCardInitialized;
	static bool isOwned;
	Player* Owner;

	virtual bool ReadCardCommon(Grid* pGrid);
	virtual void ApplyCommon(Grid* pGrid, Player* pPlayer);

public:
	Card9_11(const CellPosition& pos, int cardNum);
	virtual void ReadCardParameters(Grid* pGrid);
	virtual void Apply(Grid* pGrid, Player* pPlayer);
	~Card9_11();
};

