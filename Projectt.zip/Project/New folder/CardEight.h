#pragma once
#include "Card.h"
class CardEight : public Card
{
	int amount;
public:
	CardEight(const CellPosition& pos);
	virtual void ReadCardParameters(Grid* pGrid);

	virtual void Apply(Grid* pGrid, Player* pPlayer);
	~CardEight();
};

