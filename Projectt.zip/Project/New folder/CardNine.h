#pragma once
#include "Card9_11.h"
class CardNine : public Card9_11
{
private:
	static bool firstCardInitialized;
	static bool isOwned;

public:
	CardNine(const CellPosition& pos);
	virtual void ReadCardParameters(Grid* pGrid);
	virtual void Apply(Grid* pGrid, Player* pPlayer);
	~CardNine();
};


