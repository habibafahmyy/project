#include "NewGame.h"
#include "Grid.h"
#include "Output.h"
#include "Input.h"
#include "Player.h"

NewGame::NewGame(ApplicationManager* pApp) : Action(pApp)
{

}
void NewGame::ReadActionParameters()
{

}
void NewGame::Execute()
{
}


