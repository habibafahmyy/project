#pragma once
#include "Card9_11.h"
class CardTen :
    public Card9_11
{

public:
	CardTen(const CellPosition& pos);
	virtual void ReadCardParameters(Grid* pGrid);
	virtual void Apply(Grid* pGrid, Player* pPlayer);
	~CardTen();
};

