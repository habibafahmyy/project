#include "CardSix.h"
CardSix::CardSix(const CellPosition& pos) :Card(pos)
{
	cardNumber = 6;
}
void CardSix::ReadCardParameters(Grid* pGrid)
{
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	pOut->PrintMessage("New CardSix: Enter cell number: ");
	int value = pIn->GetInteger(pOut);
	if (value >= 0 && value < 100)
	{
		cellnum = value;
	}

}

void CardSix::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer);
	int diff;
	diff = cellnum - pPlayer->GetCell()->GetCellPosition().GetCellNum();
	
	pPlayer->Move(pGrid, diff);
	if (pPlayer->GetCell()->GetGameObject() == NULL)
	{
		pPlayer->SetTurnCount(pPlayer->GetTurnCount() - 1);
		
	}
}
CardSix::~CardSix()
{

}
