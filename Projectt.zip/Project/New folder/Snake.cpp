#include "Snake.h"

Snake::Snake(const CellPosition& startCellPos, const CellPosition& endCellPos) : GameObject(startCellPos)
{

	if (startCellPos.GetCellNum() > endCellPos.GetCellNum() && startCellPos.HCell() == endCellPos.HCell())
	{
		this->endCellPos = endCellPos;
	}

}

void Snake::Draw(Output* pOut) const
{
	pOut->DrawSnake(position, endCellPos);
}

void Snake::Apply(Grid* pGrid, Player* pPlayer)
{


	(pGrid->GetOutput())->PrintMessage("you have reached a snake. click to continue... ");
	(pGrid->GetInput()->GetCellClicked());

	
	pGrid->UpdatePlayerCell(pPlayer, endCellPos);


}

CellPosition Snake::GetEndPosition() const
{
	return endCellPos;
}

Snake::~Snake()
{
}