#include "Copy.h"
#include"CellPosition.h"
Copy::Copy(ApplicationManager* pApp):Action(pApp)
{
}
 void Copy::ReadActionParameters()
{
	 Grid* pGrid = pManager->GetGrid();
	 Output* pOut = pGrid->GetOutput();
	 Input* pIn = pGrid->GetInput();
	 pOut->PrintMessage("select the card you want to copy");
	cellpos =pIn->GetCellClicked();
	pOut->ClearStatusBar();

}
