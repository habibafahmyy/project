#pragma once
#include "Card9_11.h"
class CardEleven :
    public Card9_11
{
};

